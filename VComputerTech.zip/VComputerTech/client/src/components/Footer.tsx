import { MapPin, Phone } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-black text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-2xl font-bold text-red-500 mb-4">V-Computer</h2>
            <p className="text-gray-400 mb-4">
              Your trusted partner in technology solutions
            </p>
            <div className="flex items-start space-x-2 mb-3">
              <Phone className="h-5 w-5 text-red-500 mt-1" />
              <p className="text-gray-300">
                Vinod Gupta: <a href="tel:7704989537" className="hover:text-red-500 transition-colors">7704989537</a>
              </p>
            </div>
            <div className="flex items-start space-x-2 mb-6">
              <MapPin className="h-5 w-5 text-red-500 mt-1" />
              <div>
                <p className="text-gray-300">
                  SHOP NO.2 GANESH NAGAR,<br />
                  DAHISAR EAST MUMBAI 400068
                </p>
                <a 
                  href="https://www.google.com/maps?q=19.246790161123126,72.8652052259077"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-red-500 hover:text-red-400 transition-colors text-sm mt-1 inline-block"
                >
                  View on Google Maps
                </a>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="flex justify-end space-x-6 mb-6">
              <a href="#" className="hover:text-red-500 transition-colors">
                Facebook
              </a>
              <a href="#" className="hover:text-red-500 transition-colors">
                Twitter
              </a>
              <a href="#" className="hover:text-red-500 transition-colors">
                LinkedIn
              </a>
            </div>
            <div className="text-sm text-gray-400">
              © {new Date().getFullYear()} V-Computer. All rights reserved.
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}