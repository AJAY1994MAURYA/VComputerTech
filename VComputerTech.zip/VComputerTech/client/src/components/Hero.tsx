import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";

export function Hero() {
  return (
    <section className="bg-black text-white py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Welcome to <span className="text-red-500">V-Computer</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-300">
            Your One-Stop Solution for Tech & Innovation
          </p>
          <Button
            size="lg"
            className="bg-red-500 hover:bg-red-600 text-white"
          >
            Explore Products
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
