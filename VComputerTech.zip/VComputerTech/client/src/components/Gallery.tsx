
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";

const galleryItems = [
  {
    title: "High-Performance Gaming PCs",
    image: "https://images.pexels.com/photos/1038916/pexels-photo-1038916.jpeg",
    description: "Custom-built gaming rigs with RGB lighting and top-tier components",
  },
  {
    title: "Business Laptops",
    image: "https://images.pexels.com/photos/18105/pexels-photo.jpg",
    description: "Professional laptops for business and productivity",
  },
  {
    title: "Graphics Cards",
    image: "https://images.pexels.com/photos/5499303/pexels-photo-5499303.jpeg",
    description: "Latest NVIDIA & AMD GPUs for gaming and content creation",
  },
  {
    title: "PC Components",
    image: "https://images.pexels.com/photos/3520694/pexels-photo-3520694.jpeg",
    description: "Premium motherboards, CPUs, and RAM modules",
  },
  {
    title: "Custom PC Builds",
    image: "https://images.pexels.com/photos/4865745/pexels-photo-4865745.jpeg",
    description: "Tailored desktop solutions for your specific needs",
  },
  {
    title: "Networking Solutions",
    image: "https://images.pexels.com/photos/2881232/pexels-photo-2881232.jpeg",
    description: "Routers, switches, and networking accessories",
  },
  {
    title: "Gaming Accessories",
    image: "https://images.pexels.com/photos/7915357/pexels-photo-7915357.jpeg",
    description: "Gaming keyboards, mice, and headsets",
  },
  {
    title: "Storage Solutions",
    image: "https://images.pexels.com/photos/6804069/pexels-photo-6804069.jpeg",
    description: "SSDs, HDDs, and external storage devices",
  }
];

export function Gallery() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Our Products</h2>
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {galleryItems.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
            >
              <Card className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardContent className="p-0">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-48 object-cover"
                    onError={(e) => {
                      e.currentTarget.src = "https://placehold.co/600x400/png";
                    }}
                  />
                  <div className="p-4">
                    <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                    <p className="text-gray-600">{item.description}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
