import { Link } from "wouter";

export function Navbar() {
  return (
    <nav className="bg-black text-white py-4">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link href="/">
          <a className="text-2xl font-bold text-red-500">V-Computer</a>
        </Link>
        <div className="hidden md:flex space-x-6">
          <Link href="#products">
            <a className="hover:text-red-500 transition-colors">Products</a>
          </Link>
          <Link href="#about">
            <a className="hover:text-red-500 transition-colors">About</a>
          </Link>
          <Link href="#contact">
            <a className="hover:text-red-500 transition-colors">Contact</a>
          </Link>
        </div>
      </div>
    </nav>
  );
}
